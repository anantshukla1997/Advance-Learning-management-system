package com.kamjritztex.advancedLearningManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvancedLearningManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvancedLearningManagementSystemApplication.class, args);
	}

}
