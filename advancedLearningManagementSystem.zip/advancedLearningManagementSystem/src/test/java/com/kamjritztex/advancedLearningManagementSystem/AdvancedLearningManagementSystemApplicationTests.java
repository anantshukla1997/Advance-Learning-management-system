package com.kamjritztex.advancedLearningManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedLearningManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
